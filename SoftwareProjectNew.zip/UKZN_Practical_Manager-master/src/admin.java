import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
public class Admin extends JFrame{
    private JComboBox comboBox1;
    private JPanel adminPanel;
    private JButton homeButton;
    private JLabel usernameLabel;
    private JLabel greetingLabel;


    public Admin(){
        setVisible(true);
        setContentPane(adminPanel);
        setSize(800,440);
        homeButton.addActionListener(e -> {
            Login main = new Login();
            dispose();
        });
        comboBox1.addActionListener(e -> {
            String selectedValue = (String) comboBox1.getSelectedItem();
            AdminPracs prac1 = new AdminPracs();
            prac1.setLabel(selectedValue);
            prac1.setUsernameLabel(usernameLabel.getText());
            dispose();
        });
    }
    public void setUserStatusLabel(String text) {
        usernameLabel.setText(text);
    }
    public void setGreetingLabel(String nameFromdb) {
        greetingLabel.setText("Hello, " + nameFromdb);
    }
}
