# UKZN_Practical_Manager
run Main.java file on intellij with jdbc library and java jdk installed
