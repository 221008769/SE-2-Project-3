
public class Main {
    public static void main(String[] args) {

       mainPanel main = new mainPanel();
    }
}